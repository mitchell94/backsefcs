const Sequelize = require('sequelize');
const message = require('../../messages');
const Op = Sequelize.Op;
const Model = require('../../models').Module;
const Privilege = require('../../models').Privilege;
module.exports = {
    create: function (req, res) {
        return Model
            .max('id', {paranoid: false})
            .then(max => {
                return Model
                    .create({
                        id: max + 1,
                        id_parent: req.body.id_parent,
                        code: req.body.code,
                        order: req.body.order,
                        denomination: req.body.denomination,
                        url: req.body.url,

                        module_name: req.body.module_name,
                        type: req.body.type,
                        classes: req.body.classes,
                        icon: req.body.icon,

                    })
                    .then(record => {
                        res.status(200).send({
                            message: message.REGISTERED_OK,
                            record: record
                        });
                    })
                    .catch(error => res.status(400).send(error))
            })
            .catch(error => res.status(444).send(error))
    },
    //LISTAR MODULOS - SECURITY-MODULES
    list: function (req, res) {
        return Model
            .findAll({
                    where: {
                        id_parent: null
                    },
                    attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                    include: {
                        attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                        model: Model,
                        as: 'children',
                        include: {
                            attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                            model: Model,
                            as: 'children',
                            include: {
                                attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                                model: Model,
                                as: 'children',
                                include: {
                                    attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                                    model: Model,
                                    as: 'children',
                                    include: {
                                        attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                                        model: Model,
                                        as: 'children',

                                    }
                                }
                            }
                        }
                    },
                    order:
                        [
                            [
                                'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ]
                        ]
                }
            )
            .then(records => res.status(200).send(records))
            .catch(error => res.status(400).send(error));
    },
    listJson: function (req, res) {
        return Model.findAll({
            order: [['id', 'asc']]
        })
            .then(records => res.status(200).send(records))
            .catch(error => res.status(400).send(error));
    },
    //LIST NAVIGATION BAR MODE GOD
    listNav: function (req, res) {
        return Model
            .findAll({
                    where: {
                        id_parent: null
                    },
                    attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                    include: {
                        attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                        model: Model,
                        as: 'children',
                        include: {
                            attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                            model: Model,
                            as: 'children',
                            include: {
                                attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                                model: Model,
                                as: 'children',
                                include: {
                                    attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                                    model: Model,
                                    as: 'children',
                                    include: {
                                        attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                                        model: Model,
                                        as: 'children',

                                    }
                                }
                            }
                        }
                    },
                    order:
                        [
                            [
                                'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ]
                        ]
                }
            )
            .then(records => res.status(200).send(records))
            .catch(error => res.status(400).send(error));
    },
    //LIST NAVIGATION BAR MODE ROLE
    listNavRole: function (req, res) {
        return Model
            .findAll({
                    where: {
                        id_parent: null
                    },

                    attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                    include: [
                        {
                            required: false,
                            where: {id_role: req.params.id},
                            attributes: ['id', 'id_module', 'permit', 'state'],
                            model: Privilege,
                            as: 'Privilege'
                        },
                        {

                            attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                            model: Model,
                            as: 'children',
                            include: [
                                {
                                    required: false,
                                    where: {id_role: req.params.id},
                                    attributes: ['id', 'id_module', 'permit', 'state'],
                                    model: Privilege,
                                    as: 'Privilege'
                                },
                                {

                                    attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                                    model: Model,
                                    as: 'children',
                                    include: [
                                        {
                                            required: false,
                                            where: {id_role: req.params.id},
                                            attributes: ['id', 'id_module', 'permit', 'state'],
                                            model: Privilege,
                                            as: 'Privilege'
                                        },
                                        {

                                            attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                                            model: Model,
                                            as: 'children',
                                            include: [
                                                {
                                                    required: false,
                                                    where: {id_role: req.params.id},
                                                    attributes: ['id', 'id_module', 'permit', 'state'],
                                                    model: Privilege,
                                                    as: 'Privilege'
                                                },
                                                {

                                                    attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                                                    model: Model,
                                                    as: 'children',
                                                    include: [
                                                        {
                                                            required: false,
                                                            where: {id_role: req.params.id},
                                                            attributes: ['id', 'id_module', 'permit', 'state'],
                                                            model: Privilege,
                                                            as: 'Privilege'
                                                        },
                                                        {

                                                            attributes: [['module_name', 'id'], ['denomination', 'title'], 'type', 'url', 'classes', 'icon', 'order', 'state'],
                                                            model: Model,
                                                            as: 'children',

                                                        },

                                                    ]
                                                }

                                            ]
                                        }

                                    ]
                                }

                            ]
                        }

                    ],
                    order:
                        [

                            [
                                'order', 'asc',
                            ],
                            [
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            //


                        ]
                }
            )
            .then(record => {


                res.status(200).send(record)
            })
            .catch(error => res.status(400).send(error));
    },

    // LISTAR MODULOS + PRIVILEGIOS + ROLES
    listWithRole: function (req, res) {
        return Model
            .findAll({
                    where: {
                        id_parent: null
                    },

                    attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                    include: [
                        {
                            required: false,
                            where: {id_role: req.params.id},
                            attributes: ['id', 'permit', 'state'],
                            model: Privilege,
                            as: 'Privilege'
                        },
                        {

                            attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                            model: Model,
                            as: 'children',
                            include: [
                                {
                                    required: false,
                                    where: {id_role: req.params.id},
                                    attributes: ['id', 'permit', 'state'],
                                    model: Privilege,
                                    as: 'Privilege'
                                },
                                {

                                    attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                                    model: Model,
                                    as: 'children',
                                    include: [
                                        {
                                            required: false,
                                            where: {id_role: req.params.id},
                                            attributes: ['id', 'permit', 'state'],
                                            model: Privilege,
                                            as: 'Privilege'
                                        },
                                        {

                                            attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                                            model: Model,
                                            as: 'children',
                                            include: [
                                                {
                                                    required: false,
                                                    where: {id_role: req.params.id},
                                                    attributes: ['id', 'permit', 'state'],
                                                    model: Privilege,
                                                    as: 'Privilege'
                                                },
                                                {

                                                    attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                                                    model: Model,
                                                    as: 'children',
                                                    include: [
                                                        {
                                                            required: false,
                                                            where: {id_role: req.params.id},
                                                            attributes: ['id', 'permit', 'state'],
                                                            model: Privilege,
                                                            as: 'Privilege'
                                                        },
                                                        {

                                                            attributes: ['id', 'id_parent', 'code', 'order', 'url', ['denomination', 'text'], 'state'],
                                                            model: Model,
                                                            as: 'children',

                                                        },

                                                    ]
                                                }

                                            ]
                                        }

                                    ]
                                }

                            ]
                        }

                    ],
                    order:
                        [

                            [
                                'order', 'asc',
                            ],
                            [
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'}, 'order', 'asc'
                            ],
                            [
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            [
                                {model: Model, as: 'children'},
                                {model: Model, as: 'children'},
                                {model: Privilege, as: 'Privilege'}, 'permit', 'asc'
                            ],
                            //


                        ]
                }
            )
            .then(record => {


                res.status(200).send(record)
            })
            .catch(error => res.status(400).send(error));
    },

    retrieve: function (req, res) {
        return Model
            .findOne({
                where: {
                    id: {
                        [Op.eq]: req.params.id
                    }
                }
            })
            .then(record => {
                if (!record) return res.status(404).send({message: message.RECORD_NOT_FOUND});
                return res.status(200).send(record);
            })
            .catch(error => res.status(400).send(error));
    },

    update: function (req, res) {
        return Model
            .findOne({
                where: {
                    id: {
                        [Op.eq]: req.params.id
                    }
                }
            })
            .then(record => {
                if (!record) return res.status(404).send({message: message.RECORD_NOT_FOUND});
                return record
                    .update({
                        id_parent: req.body.id_parent,
                        code: req.body.code,
                        order: req.body.order,
                        denomination: req.body.denomination,
                        url: req.body.url,
                        abbreviation: req.body.abbreviation
                    })
                    .then(updated => {
                        res.status(200).send({
                            message: message.UPDATED_OK,
                            record: updated
                        });
                    })
                    .catch((error) => res.status(400).send(error));
            })
            .catch((error) => res.status(400).send(error));
    },

    destroy: function (req, res) {
        return Model
            .findOne({
                where: {
                    id: {
                        [Op.eq]: req.params.id
                    }
                }
            })
            .then(record => {
                if (!record) return res.status(400).send({message: message.RECORD_NOT_FOUND});
                return record
                    .destroy()
                    .then(() => res.status(200).send({message: message.DELETED_OK}))
                    .catch(error => res.status(400).send(error));
            })
            .catch(error => res.status(400).send(error));
    },
};
